## Historias de usuario

### Como usuário, desejo fazer login no sistema para ter acesso as funcionalidades do sistema.

### Como secretaria desejo gerar o curriculo para cada semestre afim de ter um controle dos alunos que estão cursando a disciplina.

### Como secretaria desejo gerenciar professores, para ter um controle maior dos professores ativos.

### Como secretaria desejo gerenciar alunos, para ter um controle maior dos alunos cadastrados.

### Como secretaria desejo gerenciar disciplinas, para ter um controle maior do semestre.

### Como aluno desejo me matricular em várias disciplinas para que eu possa cursar o semestre.

### Como aluno desejo cancelar minha matrícula feita anteriormente para ter um controle maior das disciplinas que estou cursando.

### Como professor desejo visualizar as diciplinas que estou lecionando para ter um controle maior do semestre.

### Como professor desejo visualizar os alunos matriculados em minha disciplina para ter um controle dos alunos que estão cursando a disciplina.

### Como sistema financeiro desejo ser notificado de uma nova matricula de um aluno para que eu possa cobrar o aluno.

### Como financeiro desejo cobrar o aluno para que ele possa pagar a mensalidade.

