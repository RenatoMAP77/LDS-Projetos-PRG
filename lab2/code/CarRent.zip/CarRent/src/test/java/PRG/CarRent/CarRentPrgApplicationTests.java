package PRG.CarRent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarRentPrgApplicationTests {

	@Test
	void contextLoads() {
	}

}
